"""Simulator and metric helpers."""
