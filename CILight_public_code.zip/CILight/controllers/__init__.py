"""CI-MPC controller implementations."""
