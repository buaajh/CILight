"""Shared terminal cost learning."""
